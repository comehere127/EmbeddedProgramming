/*-----------------CHUONG TRINH DIEU KHIEN DEN GIAO THONG-------------
   NHOM THUC HIEN:   1.PHAM QUANG LUAN
                     2.TRAN DANH LONG
                     3.NGUYEN TUAN NINH
   LOP           :K43DDK----HP:43S
   GVHD          :NGUYEN VAN HUY
   NGAY THUC HIEN: 5/2011
*/
#include <16F877A.h>
#fuses NOWDT,PUT,XT,NOPROTECT
#use delay(clock=20000000)       //su dung thach anh tan so 20MHz
int8 count,time,l1,l2,i,t2,t3,t1,d;
unsigned char LED[10]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90}; //Ma led 7 thanh
unsigned char den[6]={0x81,0x82,0x84,0x18,0x28,0x48};
//Chuong trinh ngat TIMER0 theo chu ki 1s giam thoi gan xuong 1 don vi
#int_timer0
void timer0()
{  
   set_timer0(0);       //thoi gian dinh thi T = 256/5*(256 - 0)*10^-6 = 0.0131072s 
      ++count;
    if(count == 76)     // 76*0.0131072s = 0.9961472s = 1s
{
   count=0;
   time--;if(time==-1) time=t3;
}
}
//Chuong trinh hien thi thoi gian dem nguoc tren led 7 thanh 
void led7()
{   if(time>t1)
         {
            l1=((time-t1-1)/   1) % 10;      // Lay so hang don vi
            l2=((time-t1-1)/  10) % 10;      // Lay so hang chuc
         }
       else{
            l1=(time/   1) % 10;             // Lay so hang don vi
            l2=(time/  10) % 10;             // Lay so hang chuc
         }
         output_d(LED[l2]);
         output_high(pin_c0);delay_us(0.001);// bat led 1 hien thi hang don vi
         output_low(pin_c0);
         output_d(LED[l1]);
         output_high(pin_c1);delay_us(0.001);// bat led 2 hien thi hang chuc
         output_low(pin_c1);
}
void hienthi()
{   while(1){
      output_b(den[d]);
      led7();
         if(time<=t3&&time>=t3-t2)           d=0; //re trai nhanh 1 do nhanh 2
         if(time<t3-t2&&time>t1+4)           d=1; // di thang nhanh 1 do nhanh 2
         if(time<=t1+4&&time>t1)             d=2; // vang nhanh 1 do nhanh 2
         if(time<=t1&&time>=t1-t2)           d=3; //re trai nhanh 2 do nhanh 1
         if(time<t1-t2&&time>3)              d=4; // di thang nhanh 2 do nhanh 1
         if(time<=3)                         d=5; // vang nhanh 2 do nhanh 1
   } 
}
// hien thi thoi gian thiet lap
void set(int8 tg)
{        l1=(tg/   1) % 10;     // Lay so hang don vi
         l2=(tg/  10) % 10;     // Lay so hang chuc
     for(i=0;i<10;i++){
         output_d(LED[l2]);
         output_high(pin_c0);delay_ms(50);
         output_low(pin_c0);
         output_d(LED[l1]);
         output_high(pin_c1);delay_ms(50);
         output_low(pin_c1);
     }
}
void main()
{  int8 t=0,j=0,kt=0;
   set_tris_c(0x00);
   set_tris_b(0x00);
   set_tris_e(0xff);
   output_b(0x00);
   output_c(0x00);
 while(1)               //thiet lap thoi gian cho he thong
   {     if(input(pin_e0)==0){t++;set(10*t+j);kt=1;}  //nhap so giay hang chuc
         if(input(pin_e1)==0){j++;set(10*t+j);kt=1;}  // nhap so giay hang don vi
         if(input(pin_e2)==0) break;                  //chay chuong trinh
   }
         if(kt==1) {
            t1=10*t+j;
            t2=t1/3;
            t3=2*t1+1;}                   //chu ki den la 2*t1
         else {
            t1=30;
            t2=10;
            t3=61;}
            time=t3;
      enable_interrupts(int_timer0);            // cho phep ngat timer0
      setup_timer_0(RTCC_INTERNAL|RTCC_DIV_256);// cai dat timer voi bo chi tan la 256
      enable_interrupts(global);                // cho phep ngat toan cuc
      hienthi();
}
